-- Run in Supabase SQL Editor AFTER you have created an account on the site.
-- 1) Make yourself admin (replace the email):
update public.profiles set role = 'admin'
where id = (select id from auth.users where email = 'YOUR_EMAIL@example.com');

-- 2) Approve your store (new stores start as 'pending'):
-- update public.stores set status = 'active' where slug = 'your-store-slug';

-- 3) Publish products a seller added (they start as 'draft'):
-- update public.products set status = 'published' where status in ('draft','pending');
