-- FurniCity initial marketplace schema for Supabase PostgreSQL.
-- Apply this in Supabase SQL Editor or with `supabase db push` after linking your project.
create extension if not exists pgcrypto with schema extensions;

create type public.app_role as enum ('buyer','seller','content_author','moderator','support','manager','finance','admin','super_admin');
create type public.store_status as enum ('pending','active','suspended');
create type public.product_status as enum ('draft','pending','published','archived','rejected');
create type public.order_status as enum ('pending','confirmed','processing','ready_for_delivery','completed','cancelled','refund_requested','refunded');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default '' check (char_length(display_name) <= 100),
  avatar_url text,
  role public.app_role not null default 'buyer',
  locale text not null default 'kk' check (locale in ('kk','ru','en')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.stores (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid references public.profiles(id) on delete set null,
  name text not null check (char_length(name) between 2 and 120),
  slug text not null unique check (slug ~ '^[a-z0-9]+(-[a-z0-9]+)*$'),
  description text not null default '' check (char_length(description) <= 2000),
  city text not null default 'Turkistan' check (char_length(city) <= 100),
  phone text check (phone is null or char_length(phone) <= 40),
  logo_url text,
  status public.store_status not null default 'pending',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.categories (
  id uuid primary key default gen_random_uuid(),
  slug text not null unique check (slug ~ '^[a-z0-9]+(-[a-z0-9]+)*$'),
  name_kk text not null,
  name_ru text not null,
  name_en text not null,
  sort_order integer not null default 0,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

create table public.products (
  id uuid primary key default gen_random_uuid(),
  store_id uuid not null references public.stores(id) on delete cascade,
  category_slug text not null references public.categories(slug),
  slug text not null unique check (slug ~ '^[a-z0-9]+(-[a-z0-9]+)*$'),
  title text not null check (char_length(title) between 2 and 160),
  description text not null default '' check (char_length(description) <= 5000),
  price numeric(14,2) not null check (price > 0),
  currency char(3) not null default 'KZT' check (currency in ('KZT','USD','EUR','RUB')),
  stock_quantity integer not null default 0 check (stock_quantity between 0 and 1000000),
  image_url text,
  status public.product_status not null default 'draft',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.favorites (
  user_id uuid not null references public.profiles(id) on delete cascade,
  product_id uuid not null references public.products(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, product_id)
);

create table public.reviews (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  product_id uuid not null references public.products(id) on delete cascade,
  rating smallint not null check (rating between 1 and 5),
  body text not null default '' check (char_length(body) <= 2000),
  status text not null default 'pending' check (status in ('pending','published','rejected')),
  created_at timestamptz not null default now(),
  unique (user_id, product_id)
);

create table public.orders (
  id uuid primary key default gen_random_uuid(),
  order_number text not null unique,
  buyer_id uuid not null references public.profiles(id),
  store_id uuid not null references public.stores(id),
  status public.order_status not null default 'pending',
  total_amount numeric(14,2) not null check (total_amount >= 0),
  currency char(3) not null default 'KZT',
  shipping_address jsonb not null,
  buyer_phone text not null check (char_length(buyer_phone) between 5 and 40),
  idempotency_key uuid,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (buyer_id, idempotency_key)
);

create table public.order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  product_id uuid not null references public.products(id),
  product_title_snapshot text not null,
  unit_price numeric(14,2) not null check (unit_price > 0),
  quantity integer not null check (quantity between 1 and 1000),
  line_total numeric(14,2) generated always as (unit_price * quantity) stored,
  created_at timestamptz not null default now()
);

create table public.support_tickets (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.profiles(id) on delete set null,
  email text not null check (char_length(email) <= 254),
  subject text not null check (char_length(subject) between 3 and 160),
  message text not null check (char_length(message) between 5 and 5000),
  status text not null default 'open' check (status in ('open','in_progress','resolved','closed')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.ad_campaigns (
  id uuid primary key default gen_random_uuid(),
  store_id uuid references public.stores(id) on delete cascade,
  title text not null check (char_length(title) between 2 and 140),
  placement text not null check (placement in ('home_hero','catalog_banner','category_tile')),
  target_url text,
  starts_at timestamptz,
  ends_at timestamptz,
  budget numeric(14,2) not null default 0 check (budget >= 0),
  status text not null default 'draft' check (status in ('draft','pending','active','paused','ended')),
  created_at timestamptz not null default now()
);

create table public.audit_events (
  id bigint generated always as identity primary key,
  actor_id uuid references public.profiles(id) on delete set null,
  event_type text not null check (char_length(event_type) between 2 and 100),
  target_type text not null check (char_length(target_type) <= 100),
  target_id text,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create index products_public_catalog_idx on public.products(status, category_slug, created_at desc);
create index products_store_idx on public.products(store_id, status, created_at desc);
create index stores_status_city_idx on public.stores(status, city, created_at desc);
create index orders_buyer_date_idx on public.orders(buyer_id, created_at desc);
create index orders_store_date_idx on public.orders(store_id, created_at desc);
create index reviews_product_idx on public.reviews(product_id, status, created_at desc);
create index support_tickets_status_idx on public.support_tickets(status, created_at desc);

create or replace function public.set_updated_at()
returns trigger language plpgsql set search_path = '' as $$
begin new.updated_at = now(); return new; end;
$$;

create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path = '' as $$
  select exists (
    select 1 from public.profiles p
    where p.id = (select auth.uid()) and p.role in ('admin','super_admin')
  );
$$;

create or replace function public.protect_moderated_status()
returns trigger language plpgsql security definer set search_path = '' as $$
begin
  if not public.is_admin() and new.status is distinct from old.status then
    raise exception 'Status changes require moderator approval.' using errcode = '42501';
  end if;
  return new;
end;
$$;

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = '' as $$
begin
  insert into public.profiles (id, display_name, role)
  values (new.id, coalesce(nullif(left(new.raw_user_meta_data->>'display_name', 100), ''), split_part(coalesce(new.email, 'member'), '@', 1)), 'buyer')
  on conflict (id) do nothing;
  return new;
end;
$$;

create trigger auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();
create trigger profiles_updated_at before update on public.profiles
for each row execute procedure public.set_updated_at();
create trigger stores_updated_at before update on public.stores
for each row execute procedure public.set_updated_at();
create trigger stores_protect_status before update on public.stores
for each row execute procedure public.protect_moderated_status();
create trigger products_updated_at before update on public.products
for each row execute procedure public.set_updated_at();
create trigger products_protect_status before update on public.products
for each row execute procedure public.protect_moderated_status();
create trigger orders_updated_at before update on public.orders
for each row execute procedure public.set_updated_at();
create trigger support_updated_at before update on public.support_tickets
for each row execute procedure public.set_updated_at();

-- Create an order atomically using database-side product prices and stock checks.
-- The JSON array must contain entries such as [{"product_id":"uuid","quantity":2}].
create or replace function public.place_order(
  p_items jsonb,
  p_shipping_address jsonb,
  p_buyer_phone text,
  p_idempotency_key uuid
)
returns table(order_id uuid, order_number text, store_id uuid, total_amount numeric)
language plpgsql security definer set search_path = '' as $$
declare
  v_user uuid := auth.uid();
  v_item jsonb;
  v_product public.products%rowtype;
  v_store public.stores%rowtype;
  v_order_id uuid;
  v_order_number text;
  v_store_total numeric(14,2);
  v_current_store uuid;
  v_group jsonb;
  v_quantity integer;
  v_total numeric(14,2);
  v_key uuid := coalesce(p_idempotency_key, gen_random_uuid());
begin
  if v_user is null then raise exception 'Sign in required' using errcode = '28000'; end if;
  if jsonb_typeof(p_items) <> 'array' or jsonb_array_length(p_items) < 1 or jsonb_array_length(p_items) > 30 then
    raise exception 'Order must contain 1 to 30 product lines';
  end if;
  if jsonb_typeof(p_shipping_address) <> 'object' or char_length(coalesce(p_buyer_phone,'')) < 5 then
    raise exception 'Shipping address and contact phone are required';
  end if;

  -- Return an already-created batch when the client retries with the same idempotency key.
  if p_idempotency_key is not null then
    return query
      select o.id, o.order_number, o.store_id, o.total_amount
      from public.orders o
      where o.buyer_id = v_user
        and o.idempotency_key = md5(v_user::text || ':' || p_idempotency_key::text || ':' || o.store_id::text)::uuid
        and exists (
          select 1 from jsonb_array_elements(p_items) i(value)
          join public.products p on p.id = (i.value->>'product_id')::uuid
          where p.store_id = o.store_id
        )
      order by o.store_id;
    if found then return; end if;
  end if;

  -- Lock products in stable id order, validate published status/stock, then split by store.
  for v_item in
    select value from jsonb_array_elements(p_items) order by (value->>'product_id')
  loop
    v_quantity := (v_item->>'quantity')::integer;
    if v_quantity < 1 or v_quantity > 1000 then raise exception 'Invalid item quantity'; end if;
    select * into v_product from public.products where id = (v_item->>'product_id')::uuid for update;
    if not found or v_product.status <> 'published' then raise exception 'Product is unavailable'; end if;
    if v_product.stock_quantity < v_quantity then raise exception 'Insufficient stock for %', v_product.title; end if;
  end loop;

  for v_group in
    select jsonb_build_object('store_id', p.store_id::text, 'items', jsonb_agg(jsonb_build_object('product_id', p.id::text, 'quantity', (i.value->>'quantity')::integer)))
    from jsonb_array_elements(p_items) i(value)
    join public.products p on p.id = (i.value->>'product_id')::uuid
    group by p.store_id order by p.store_id::text
  loop
    v_current_store := (v_group->>'store_id')::uuid;
    v_key := md5(v_user::text || ':' || coalesce(p_idempotency_key::text, gen_random_uuid()::text) || ':' || v_current_store::text)::uuid;
    select * into v_store from public.stores where id = v_current_store and status = 'active';
    if not found then raise exception 'Store is unavailable'; end if;
    v_store_total := 0;
    v_order_id := gen_random_uuid();
    v_order_number := 'FC-' || upper(substr(replace(v_order_id::text, '-', ''), 1, 10));
    for v_item in select value from jsonb_array_elements(v_group->'items') loop
      v_quantity := (v_item->>'quantity')::integer;
      select * into v_product from public.products where id = (v_item->>'product_id')::uuid for update;
      v_total := v_product.price * v_quantity;
      v_store_total := v_store_total + v_total;
      update public.products set stock_quantity = stock_quantity - v_quantity where id = v_product.id;
      insert into public.order_items(order_id, product_id, product_title_snapshot, unit_price, quantity)
      values (v_order_id, v_product.id, v_product.title, v_product.price, v_quantity);
    end loop;
    insert into public.orders(id, order_number, buyer_id, store_id, total_amount, currency, shipping_address, buyer_phone, idempotency_key)
    values (v_order_id, v_order_number, v_user, v_current_store, v_store_total, 'KZT', p_shipping_address, p_buyer_phone, v_key);
    order_id := v_order_id; order_number := v_order_number; store_id := v_current_store; total_amount := v_store_total;
    return next;
  end loop;
end;
$$;

-- Roles: the browser can never promote itself to a seller/moderator/admin by updating profiles.
revoke all on public.profiles from anon, authenticated;
grant select on public.profiles to authenticated;
grant update (display_name, avatar_url, locale) on public.profiles to authenticated;
revoke all on public.stores, public.categories, public.products, public.favorites, public.reviews, public.orders, public.order_items, public.support_tickets, public.ad_campaigns, public.audit_events from anon, authenticated;
grant select on public.stores, public.categories, public.products to anon, authenticated;
grant select, insert, update, delete on public.stores to authenticated;
grant select, insert, update, delete on public.products to authenticated;
grant select, insert, delete on public.favorites to authenticated;
grant select, insert, update on public.reviews to authenticated;
grant select on public.orders, public.order_items to authenticated;
grant insert on public.support_tickets to anon, authenticated;
grant select, insert, update on public.ad_campaigns to authenticated;
grant select on public.audit_events to authenticated;
grant usage, select on sequence public.audit_events_id_seq to authenticated;
revoke all on function public.place_order(jsonb, jsonb, text, uuid) from public, anon;
grant execute on function public.place_order(jsonb, jsonb, text, uuid) to authenticated;

alter table public.profiles enable row level security;
alter table public.stores enable row level security;
alter table public.categories enable row level security;
alter table public.products enable row level security;
alter table public.favorites enable row level security;
alter table public.reviews enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;
alter table public.support_tickets enable row level security;
alter table public.ad_campaigns enable row level security;
alter table public.audit_events enable row level security;

create policy "profiles read self or admin" on public.profiles for select to authenticated using (id = (select auth.uid()) or public.is_admin());
create policy "profiles update own safe fields" on public.profiles for update to authenticated using (id = (select auth.uid())) with check (id = (select auth.uid()));
create policy "profiles admin all" on public.profiles for all to authenticated using (public.is_admin()) with check (public.is_admin());

create policy "active stores public" on public.stores for select to anon, authenticated using (status = 'active' or owner_id = (select auth.uid()) or public.is_admin());
create policy "store owners create pending stores" on public.stores for insert to authenticated with check (owner_id = (select auth.uid()) and status = 'pending');
create policy "store owners update their stores" on public.stores for update to authenticated using (owner_id = (select auth.uid()) or public.is_admin()) with check ((owner_id = (select auth.uid()) and status in ('pending','active')) or public.is_admin());
create policy "store admins delete" on public.stores for delete to authenticated using (public.is_admin());

create policy "active categories public" on public.categories for select to anon, authenticated using (is_active or public.is_admin());
create policy "category admins manage" on public.categories for all to authenticated using (public.is_admin()) with check (public.is_admin());

create policy "published products public" on public.products for select to anon, authenticated using (status = 'published' or exists(select 1 from public.stores s where s.id = store_id and s.owner_id = (select auth.uid())) or public.is_admin());
create policy "store owners create drafts" on public.products for insert to authenticated with check (status in ('draft','pending') and exists(select 1 from public.stores s where s.id = store_id and s.owner_id = (select auth.uid())));
create policy "store owners update own products" on public.products for update to authenticated using (exists(select 1 from public.stores s where s.id = store_id and s.owner_id = (select auth.uid())) or public.is_admin()) with check ((status in ('draft','pending','published','archived','rejected') and exists(select 1 from public.stores s where s.id = store_id and s.owner_id = (select auth.uid()))) or public.is_admin());
create policy "store owners or admins delete products" on public.products for delete to authenticated using (exists(select 1 from public.stores s where s.id = store_id and s.owner_id = (select auth.uid())) or public.is_admin());

create policy "users read own favorites" on public.favorites for select to authenticated using (user_id = (select auth.uid()) or public.is_admin());
create policy "users add own favorites" on public.favorites for insert to authenticated with check (user_id = (select auth.uid()));
create policy "users remove own favorites" on public.favorites for delete to authenticated using (user_id = (select auth.uid()) or public.is_admin());

create policy "published reviews public" on public.reviews for select to anon, authenticated using (status = 'published' or user_id = (select auth.uid()) or public.is_admin());
create policy "users write own pending reviews" on public.reviews for insert to authenticated with check (user_id = (select auth.uid()) and status = 'pending');
create policy "users update own pending reviews" on public.reviews for update to authenticated using (user_id = (select auth.uid()) or public.is_admin()) with check ((user_id = (select auth.uid()) and status = 'pending') or public.is_admin());
create policy "admins delete reviews" on public.reviews for delete to authenticated using (public.is_admin());

create policy "buyers and store owners read orders" on public.orders for select to authenticated using (buyer_id = (select auth.uid()) or exists(select 1 from public.stores s where s.id = store_id and s.owner_id = (select auth.uid())) or public.is_admin());
create policy "order items visible to parties" on public.order_items for select to authenticated using (exists(select 1 from public.orders o where o.id = order_id and (o.buyer_id = (select auth.uid()) or exists(select 1 from public.stores s where s.id = o.store_id and s.owner_id = (select auth.uid())) or public.is_admin())));

create policy "support ticket insert restricted" on public.support_tickets for insert to anon, authenticated with check ((user_id is null and auth.uid() is null) or user_id = (select auth.uid()));
create policy "support users read own tickets" on public.support_tickets for select to authenticated using (user_id = (select auth.uid()) or public.is_admin());
create policy "support admin update" on public.support_tickets for update to authenticated using (public.is_admin()) with check (public.is_admin());

create policy "active ads public" on public.ad_campaigns for select to anon, authenticated using (status = 'active' and (starts_at is null or starts_at <= now()) and (ends_at is null or ends_at > now()) or public.is_admin() or exists(select 1 from public.stores s where s.id = store_id and s.owner_id = (select auth.uid())));
create policy "admins manage ads" on public.ad_campaigns for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "admins read audit log" on public.audit_events for select to authenticated using (public.is_admin());

-- Initial categories are multi-language by design.
insert into public.categories (slug,name_kk,name_ru,name_en,sort_order) values
('sofas','Дивандар','Диваны','Sofas',1),
('beds','Кереуеттер','Кровати','Beds',2),
('tables','Үстелдер','Столы','Tables',3),
('chairs','Орындықтар','Стулья','Chairs',4),
('storage','Сақтау жүйесі','Хранение','Storage',5),
('decor','Үй декоры','Декор','Home decor',6)
on conflict (slug) do nothing;

-- Sample stores are active but unclaimed; the real owner can be linked later by an admin.
insert into public.stores (name,slug,description,city,status) values
('Qara Wood Studio','qara-wood-studio','Solid wood, quiet shapes, made for everyday living.','Turkistan','active'),
('Nomad Home','nomad-home','Warm materials and thoughtful furniture for modern homes.','Turkistan','active'),
('Forma Living','forma-living','Contemporary furniture for considered spaces.','Turkistan','active')
on conflict (slug) do nothing;

insert into public.products (store_id,category_slug,slug,title,description,price,stock_quantity,status)
select s.id, x.category_slug, x.slug, x.title, x.description, x.price, x.stock_quantity, 'published'
from (values
  ('qara-wood-studio','sofas','luma-modular-sofa','Luma Modular Sofa','Soft modular sofa with textured upholstery and deep seats.',389000::numeric,4),
  ('forma-living','chairs','forma-lounge-chair','Forma Lounge Chair','Sculptural accent chair with a curved back and oak legs.',128000::numeric,7),
  ('qara-wood-studio','tables','noma-oak-table','Noma Oak Dining Table','Solid oak dining table for slow mornings and long dinners.',245000::numeric,3),
  ('nomad-home','beds','sora-platform-bed','Sora Platform Bed','Low-profile bed frame with an architectural silhouette.',315000::numeric,5),
  ('nomad-home','storage','aru-sideboard','Aru Sideboard','Clean-lined storage with generous hidden space.',198000::numeric,6),
  ('forma-living','decor','tumar-ceramic-lamp','Tumar Ceramic Lamp','A sculptural lamp with a warm, quiet presence.',42000::numeric,12),
  ('forma-living','sofas','kieli-two-seater','Kieli Two-Seater','A compact two-seater designed for apartment living.',279000::numeric,3),
  ('nomad-home','tables','aspan-coffee-table','Aspan Coffee Table','Rounded coffee table with a matte mineral finish.',89000::numeric,8)
) as x(store_slug,category_slug,slug,title,description,price,stock_quantity)
join public.stores s on s.slug = x.store_slug
on conflict (slug) do nothing;
