import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const checks = [];
function check(name, condition, detail = "") { checks.push({ name, ok: Boolean(condition), detail }); }
function read(name) { return fs.readFileSync(path.join(root, name), "utf8"); }

try {
  const pkg = JSON.parse(read("package.json"));
  check("package manifest parses", pkg.name === "furnicity-marketplace" && pkg.dependencies.next, "package.json");
  check("Next.js App Router pages exist", ["app/page.tsx","app/catalog/page.tsx","app/catalog/[slug]/page.tsx","app/stores/page.tsx","app/stores/[slug]/page.tsx"].every(p => fs.existsSync(path.join(root,p))));
  const oauth = read("components/oauth-buttons.tsx");
  check("Google and Apple OAuth providers wired", oauth.includes('signInWithOAuth') && oauth.includes('provider, options') && oauth.includes('"google"') && oauth.includes('"apple"'));
  check("auth callback blocks open redirects", read("app/auth/callback/route.ts").includes('!value.startsWith("//")') && read("app/auth/callback/route.ts").includes("exchangeCodeForSession"));
  check("public env template excludes service role", read(".env.example").includes("NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY") && !read(".env.example").includes("NEXT_PUBLIC_SUPABASE_SERVICE_ROLE_KEY"));
  const sql = read("supabase/migrations/001_initial_schema.sql");
  check("database tables and RLS included", ["profiles","stores","products","favorites","orders","order_items","audit_events"].every(t => sql.includes(`public.${t}`)) && sql.includes("enable row level security"));
  check("public signup defaults to buyer role", /values\s*\(new\.id,[\s\S]*?'buyer'\)/.test(sql));
  check("server-side order RPC included", sql.includes("function public.place_order") && sql.includes("for update") && sql.includes("stock_quantity = stock_quantity - v_quantity"));
  check("seller write UX included", read("components/seller-dashboard.tsx").includes('from("stores").insert') && read("components/seller-product-form.tsx").includes('from("products").insert'));
  check("order endpoint validates origin and payload", read("app/api/orders/route.ts").includes("Cross-origin request blocked") && read("app/api/orders/route.ts").includes("uuidPattern"));
  check("manual and timed slider included", read("components/slideshow.tsx").includes("setInterval") && read("components/slideshow.tsx").includes("Previous slide"));
  check("furniture photo map covers all categories", ["sofas", "beds", "tables", "chairs", "storage", "decor"].every(category => read("lib/photos.ts").includes(`${category}:`)));
  check("mouse parallax respects touch and reduced motion", read("components/photo-motion.tsx").includes("prefers-reduced-motion: reduce") && read("components/photo-motion.tsx").includes('event.pointerType === "touch"'));
  check("photo motion is mounted application-wide", read("app/layout.tsx").includes("<PhotoMotion />"));
  check("product cards use photo-backed images", read("components/product-card.tsx").includes("furniturePhoto(product.category_slug, product.image_url)") && read("components/product-card.tsx").includes("product-photo-layer"));
  check("homepage category and store photography included", read("app/page.tsx").includes("photo-category-grid") && read("app/page.tsx").includes("store-photo-layer"));
  check("photo design reference included", fs.existsSync(path.join(root, "public/furnicity-design-reference.html")));
  const language = read("components/language-provider.tsx");
  check("Kazakh, Russian, and English dictionaries", ["kk: {", "ru: {", "en: {"].every(token => language.includes(token)) && read("components/site-header.tsx").includes('value="kk"') && read("components/site-header.tsx").includes('value="ru"') && read("components/site-header.tsx").includes('value="en"'));
  check("global search forwards query to catalog", read("components/site-header.tsx").includes("/catalog?q=${encodeURIComponent(value)}") && read("app/catalog/page.tsx").includes("searchParams") && read("components/catalog-explorer.tsx").includes("initialQuery"));
  check("favorites persist and render saved products", read("components/product-card.tsx").includes("furnicity-favorites-v1") && read("components/favorites-client.tsx").includes("products.find") && read("app/favorites/page.tsx").includes("FavoritesClient"));
  check("cart persists and updates header counter", read("components/product-card.tsx").includes("furnicity-cart-v1") && read("components/cart-client.tsx").includes("furnicity:cart-changed") && read("components/site-header.tsx").includes("furnicity:cart-changed"));
  const analytics = read("components/price-analytics.tsx");
  check("price analytics calculates low, average, high, and spread", analytics.includes("Math.round(offers.reduce") && analytics.includes("const low = offers[0]?.price") && analytics.includes("const high = offers[offers.length - 1]?.price") && analytics.includes("high-low") && read("app/compare/page.tsx").includes("PriceAnalytics"));
  check("selected comparison persists and is limited to three", analytics.includes("furnicity-compare-v1") && analytics.includes("next.length >= 3") && analytics.includes("selected-compare-section"));
} catch (error) {
  console.error("Verification could not complete:", error);
  process.exit(2);
}

for (const item of checks) console.log(`${item.ok ? "PASS" : "FAIL"}  ${item.name}${item.detail ? ` — ${item.detail}` : ""}`);
const failed = checks.filter(item => !item.ok);
console.log(`\n${checks.length - failed.length}/${checks.length} checks passed.`);
if (failed.length) process.exit(1);
