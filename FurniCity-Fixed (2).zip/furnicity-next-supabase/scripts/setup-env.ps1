$ErrorActionPreference = 'Stop'

if (-not (Test-Path '.env.example')) {
  throw 'Could not find .env.example. Run this script from the project root folder.'
}

if (Test-Path '.env.local') {
  Write-Host '.env.local already exists; leaving it unchanged.' -ForegroundColor Yellow
  exit 0
}

Copy-Item '.env.example' '.env.local'
Write-Host '.env.local created from .env.example.' -ForegroundColor Green
Write-Host 'Open .env.local and enter your own Supabase project settings. Do not share this file.' -ForegroundColor Yellow
