// Run: npm run check:supabase
// Checks .env.local, the API key, and that the migration (tables, categories, sample data) is installed.
import { existsSync } from "node:fs";

if (!existsSync(".env.local")) {
  console.error("FAIL  .env.local not found. Run: powershell -File scripts/setup-env.ps1  (or copy .env.example to .env.local)");
  process.exit(1);
}
process.loadEnvFile(".env.local");
const url = (process.env.NEXT_PUBLIC_SUPABASE_URL || "").replace(/\/$/, "");
const key = process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY || "";
if (!url || url.includes("YOUR_PROJECT") || !/^https:\/\/.+\.supabase\.co$/.test(url)) {
  console.error("FAIL  NEXT_PUBLIC_SUPABASE_URL is missing or still a placeholder (expected https://xxxx.supabase.co).");
  process.exit(1);
}
if (!key || key.includes("YOUR_SUPABASE")) {
  console.error("FAIL  NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY is missing or still a placeholder.");
  process.exit(1);
}
console.log("PASS  .env.local has a project URL and key");

async function query(path) {
  const res = await fetch(`${url}/rest/v1/${path}`, { headers: { apikey: key, Authorization: `Bearer ${key}` } });
  let body = null;
  try { body = await res.json(); } catch { /* not JSON */ }
  return { ok: res.ok, status: res.status, body };
}

let failed = 0;
for (const [label, path, min] of [
  ["categories table (needs 6)", "categories?select=slug", 6],
  ["active stores (needs 3 sample stores)", "stores?select=slug&status=eq.active", 1],
  ["published products (needs 8 sample products)", "products?select=id&status=eq.published", 1],
]) {
  try {
    const r = await query(path);
    if (!r.ok) { failed++; console.error(`FAIL  ${label}: HTTP ${r.status} ${r.body?.message ?? ""} ${r.body?.hint ?? ""}`); continue; }
    if (r.body.length < min) { failed++; console.error(`FAIL  ${label}: found ${r.body.length}`); continue; }
    console.log(`PASS  ${label}: found ${r.body.length}`);
  } catch (e) { failed++; console.error(`FAIL  ${label}: ${e.cause?.code ?? e.message} (check the URL and your internet connection)`); }
}
if (failed) { console.error(`\n${failed} check(s) failed. See SUPABASE-SETUP-KK.md.`); process.exit(1); }
console.log("\nSupabase is connected. Restart `npm run dev` if it was already running.");
