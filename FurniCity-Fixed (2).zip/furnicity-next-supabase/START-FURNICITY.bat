@echo off
setlocal
cd /d "%~dp0"
echo ============================================
echo FurniCity - local development server
echo ============================================
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js is not installed or not in PATH.
  echo Install Node.js LTS, then reopen this file.
  pause
  exit /b 1
)
where npm >nul 2>nul
if errorlevel 1 (
  echo npm is not available in PATH.
  pause
  exit /b 1
)
if not exist node_modules (
  echo Installing packages for the first time...
  call npm install
  if errorlevel 1 (
    echo Package installation failed. Check your internet connection and try again.
    pause
    exit /b 1
  )
)
echo Checking project files...
call npm run verify:scaffold
if errorlevel 1 (
  echo Project verification failed. Read the errors above.
  pause
  exit /b 1
)
echo Starting FurniCity. Leave this window open while using the site.
call npm run dev
pause
