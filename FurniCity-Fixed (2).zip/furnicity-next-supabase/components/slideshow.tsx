"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { FurnitureArt } from "@/components/furniture-art";
import { furniturePhoto, heroPhoto, showroomPhoto } from "@/lib/photos";

const slides = [
  { no: "01 / FURNITURE EDIT", title: "Pieces that give a home its character.", description: "Considered proportions, honest materials, and furniture made for everyday living.", art: "sofa", photo: heroPhoto },
  { no: "02 / PLAN YOUR SPACE", title: "Every room has its own rhythm.", description: "Bring the right pieces together and compare local collections in one place.", art: "table", photo: showroomPhoto },
  { no: "03 / LOCAL SELLERS", title: "Local stores. New possibilities.", description: "A shared digital space for Turkistan furniture stores and independent sellers.", art: "chair", photo: furniturePhoto("chairs") },
];
export function Slideshow() {
  const [index, setIndex] = useState(0);
  useEffect(() => { const timer = window.setInterval(() => setIndex(i => (i + 1) % slides.length), 6500); return () => window.clearInterval(timer); }, []);
  const slide = slides[index];
  return <section aria-label="FurniCity highlights"><div className="slider-frame" aria-live="polite"><div className="slide-copy" key={`copy-${index}`}><div className="eyebrow">{slide.no}</div><h2>{slide.title}</h2><p className="lead">{slide.description}</p><Link className="button button-dark" href="/catalog">Explore furniture ↗</Link></div><div className="slide-visual photo-motion" data-photo-motion key={`art-${index}`}><div className="slide-photo-layer" aria-hidden="true" style={{backgroundImage:`url("${slide.photo}")`}}/><FurnitureArt kind={slide.art}/></div></div><div className="slide-controls"><div className="slide-dots">{slides.map((s,i)=><button key={s.no} className={`slide-dot ${i===index?"active":""}`} onClick={()=>setIndex(i)} aria-label={`Go to slide ${i+1}`} aria-current={i===index?"step":undefined}/>)}</div><div className="arrow-buttons"><button className="arrow-button" onClick={()=>setIndex(i=>(i+slides.length-1)%slides.length)} aria-label="Previous slide">←</button><button className="arrow-button" onClick={()=>setIndex(i=>(i+1)%slides.length)} aria-label="Next slide">→</button></div></div></section>;
}
