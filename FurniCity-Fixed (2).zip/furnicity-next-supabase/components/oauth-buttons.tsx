"use client";

import { useState } from "react";
import { useSearchParams } from "next/navigation";
import { createClient } from "@/lib/supabase/client";

export function OAuthButtons() {
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState<string | null>(null);
  const params = useSearchParams();
  async function signIn(provider: "google" | "apple") {
    setError(null); setLoading(provider);
    try {
      const supabase = createClient();
      const rawNext = params.get("next");
      const next = rawNext && rawNext.startsWith("/") && !rawNext.startsWith("//") ? rawNext : "/account";
      const redirectTo = `${window.location.origin}/auth/callback?next=${encodeURIComponent(next)}`;
      const { error: authError } = await supabase.auth.signInWithOAuth({ provider, options: { redirectTo, skipBrowserRedirect: false } });
      if (authError) throw authError;
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not start authentication.");
      setLoading(null);
    }
  }
  return <div><div className="oauth-stack"><button className="oauth-button" onClick={() => signIn("google")} disabled={!!loading}><span className="oauth-logo" aria-hidden="true">G</span>{loading === "google" ? "Connecting to Google…" : "Continue with Google"}</button><button className="oauth-button" onClick={() => signIn("apple")} disabled={!!loading}><span className="oauth-logo" aria-hidden="true">●</span>{loading === "apple" ? "Connecting to Apple…" : "Continue with Apple ID"}</button></div>{error && <div className="notice error" role="alert">{error}<br/>Check the Supabase URL, publishable key, provider settings, and redirect URLs.</div>}</div>;
}
