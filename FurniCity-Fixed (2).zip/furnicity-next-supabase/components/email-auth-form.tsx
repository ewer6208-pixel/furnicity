"use client";

import { useState, type FormEvent } from "react";
import { createClient } from "@/lib/supabase/client";

export function EmailAuthForm() {
  const [mode,setMode] = useState<"signin"|"signup">("signin");
  const [message,setMessage] = useState<string|null>(null);
  const [error,setError] = useState<string|null>(null);
  const [busy,setBusy] = useState(false);
  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setBusy(true); setError(null); setMessage(null);
    const form = new FormData(event.currentTarget);
    const email = String(form.get("email")||"").trim();
    const password = String(form.get("password")||"");
    try {
      const supabase = createClient();
      const requestedNext = new URLSearchParams(window.location.search).get("next");
      const next = requestedNext && requestedNext.startsWith("/") && !requestedNext.startsWith("//") ? requestedNext : "/account";
      if(mode === "signin") {
        const {error:authError} = await supabase.auth.signInWithPassword({email,password});
        if(authError) throw authError;
        window.location.assign(next);
      } else {
        const {data,error:authError} = await supabase.auth.signUp({email,password,options:{emailRedirectTo:`${window.location.origin}/auth/callback?next=${encodeURIComponent(next)}`,data:{display_name:String(form.get("name")||"").trim(),role:"buyer"}}});
        if(authError) throw authError;
        if(data.session) window.location.assign(next);
        else setMessage("Check your email for the confirmation link. The message is sent only if email is configured in Supabase.");
      }
    } catch(err) { setError(err instanceof Error?err.message:"Authentication failed."); }
    finally { setBusy(false); }
  }
  return <><div className="divider">or use email</div><form className="form-stack" onSubmit={submit}>{mode==="signup"&&<label className="field">Full name<input name="name" autoComplete="name" maxLength={100} required/></label>}<label className="field">Email address<input name="email" type="email" autoComplete="email" maxLength={254} required/></label><label className="field">Password<input name="password" type="password" autoComplete={mode==="signin"?"current-password":"new-password"} minLength={10} maxLength={128} required/><span className="muted" style={{fontSize:9,fontWeight:400}}>At least 10 characters. Use a unique password.</span></label><button className="button button-dark" type="submit" disabled={busy}>{busy?"Working…":mode==="signin"?"Sign in ↗":"Create account ↗"}</button>{error&&<div className="notice error" role="alert">{error}</div>}{message&&<div className="notice" role="status">{message}</div>}</form><p className="muted" style={{fontSize:10,marginTop:18}}>{mode==="signin"?"New to FurniCity?":"Already have an account?"} <button className="inline-link" style={{border:0,background:"none",padding:0,color:"inherit",fontWeight:700}} onClick={()=>{setMode(mode==="signin"?"signup":"signin");setMessage(null);setError(null);}}>{mode==="signin"?"Create an account":"Sign in"}</button></p></>;
}
