"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import type { Product } from "@/lib/types";
import { FurnitureArt } from "@/components/furniture-art";
import { furniturePhoto } from "@/lib/photos";
import { useLanguage } from "@/components/language-provider";
import { formatNumber } from "@/lib/format";

const FAVORITES_KEY = "furnicity-favorites-v1";
const COMPARE_KEY = "furnicity-compare-v1";
const CART_KEY = "furnicity-cart-v1";
function readIds(key: string): string[] {
  try { const value: unknown = JSON.parse(localStorage.getItem(key) || "[]"); return Array.isArray(value) ? value.filter((id): id is string => typeof id === "string") : []; }
  catch { return []; }
}
function notify(name: string) { window.dispatchEvent(new CustomEvent(name)); }

export function ProductCard({ product }: { product: Product }) {
  const { t } = useLanguage();
  const [saved, setSaved] = useState(false);
  const [compared, setCompared] = useState(false);
  const [added, setAdded] = useState(false);
  const [notice, setNotice] = useState("");
  const categories: Record<string, string> = { sofas: t("sofas"), beds: t("beds"), tables: t("tables"), chairs: t("chairs"), storage: t("storage"), decor: t("decor") };

  useEffect(() => {
    const sync = () => { setSaved(readIds(FAVORITES_KEY).includes(product.id)); setCompared(readIds(COMPARE_KEY).includes(product.id)); };
    sync();
    window.addEventListener("furnicity:favorites-changed", sync);
    window.addEventListener("furnicity:compare-changed", sync);
    window.addEventListener("storage", sync);
    return () => { window.removeEventListener("furnicity:favorites-changed", sync); window.removeEventListener("furnicity:compare-changed", sync); window.removeEventListener("storage", sync); };
  }, [product.id]);

  function toggleFavorite() {
    const items = readIds(FAVORITES_KEY);
    const exists = items.includes(product.id);
    const next = exists ? items.filter(id => id !== product.id) : [...items, product.id];
    try { localStorage.setItem(FAVORITES_KEY, JSON.stringify(next)); } catch { /* Storage may be disabled. */ }
    setSaved(!exists); notify("furnicity:favorites-changed");
  }
  function toggleCompare() {
    const items = readIds(COMPARE_KEY);
    if (items.includes(product.id)) {
      try { localStorage.setItem(COMPARE_KEY, JSON.stringify(items.filter(id => id !== product.id))); } catch { /* Storage may be disabled. */ }
      setCompared(false); notify("furnicity:compare-changed"); return;
    }
    if (items.length >= 3) { setNotice(t("compareLimit")); window.setTimeout(() => setNotice(""), 2400); return; }
    try { localStorage.setItem(COMPARE_KEY, JSON.stringify([...items, product.id])); } catch { /* Storage may be disabled. */ }
    setCompared(true); notify("furnicity:compare-changed");
  }
  function addToCart() {
    try {
      const current = JSON.parse(localStorage.getItem(CART_KEY) || "[]") as Array<{ productId: string; quantity: number }>;
      const max = Math.max(1, product.stock_quantity || 1);
      const existing = current.find(item => item.productId === product.id);
      if (existing) existing.quantity = Math.min(max, existing.quantity + 1);
      else current.push({ productId: product.id, quantity: 1 });
      localStorage.setItem(CART_KEY, JSON.stringify(current));
      notify("furnicity:cart-changed");
      setAdded(true); window.setTimeout(() => setAdded(false), 1300);
    } catch { setNotice("Storage is unavailable in this browser."); window.setTimeout(() => setNotice(""), 2400); }
  }
  const photo = furniturePhoto(product.category_slug, product.image_url);
  return <article className="product-card" data-photo-motion>
    <div className="product-artbox">
      <div className="product-photo-layer" aria-hidden="true" style={{ backgroundImage: `url("${photo}")` }} />
      <span className="product-tag">{product.stock_quantity > 0 ? t("available") : t("soldOut")}</span>
      <FurnitureArt kind={product.category_slug} />
      <div className="product-card-actions">
        <button className={`icon-action ${saved ? "active" : ""}`} onClick={toggleFavorite} aria-label={saved ? t("removeSaved") : t("saveItem")} title={saved ? t("removeSaved") : t("saveItem")}>{saved ? "♥" : "♡"}</button>
        <button className={`icon-action ${compared ? "active" : ""}`} onClick={toggleCompare} aria-label={compared ? t("removeCompare") : t("addCompare")} title={compared ? t("removeCompare") : t("addCompare")}>⇄</button>
      </div>
    </div>
    <div className="product-store">{product.store_name ?? t("seller")} · {product.city ?? "Turkistan"}</div>
    <Link href={`/catalog/${product.slug}`}><h3 className="product-name">{product.title}</h3></Link>
    <div className="product-bottom"><div className="price">{formatNumber(product.price)} ₸</div><div className="card-actions"><button className="icon-action" onClick={addToCart} disabled={product.stock_quantity < 1} aria-label={t("addCart")} title={t("addCart")}>{added ? "✓" : "+"}</button></div></div>
    <div className="product-store" style={{ marginTop: 6 }}>{categories[product.category_slug] ?? t("allFurniture")} · {t("stock").toLowerCase()}: {product.stock_quantity}</div>
    {notice && <div className="product-inline-notice" role="status">{notice}</div>}
  </article>;
}
