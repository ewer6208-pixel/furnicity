"use client";

import { useMemo, useState } from "react";
import type { Product } from "@/lib/types";
import { ProductCard } from "@/components/product-card";
import { useLanguage } from "@/components/language-provider";

export function CatalogExplorer({ products, initialCategory = "all", initialQuery = "" }: { products: Product[]; initialCategory?: string; initialQuery?: string }) {
  const { t, language } = useLanguage();
  const [query, setQuery] = useState(initialQuery);
  const [category, setCategory] = useState(initialCategory);
  const [sort, setSort] = useState("newest");
  const categories = [["all",t("allFurniture")],["sofas",t("sofas")],["beds",t("beds")],["tables",t("tables")],["chairs",t("chairs")],["storage",t("storage")],["decor",t("decor")]] as const;
  const results = useMemo(() => {
    let items = products.filter(p => category === "all" || p.category_slug === category).filter(p => `${p.title} ${p.description ?? ""} ${p.store_name ?? ""} ${p.category_slug} ${t(p.category_slug)}`.toLocaleLowerCase().includes(query.trim().toLowerCase()));
    if (sort === "price-up") items = [...items].sort((a,b) => a.price-b.price);
    if (sort === "price-down") items = [...items].sort((a,b) => b.price-a.price);
    if (sort === "name") items = [...items].sort((a,b) => a.title.localeCompare(b.title));
    return items;
  }, [products, query, category, sort, language, t]);
  return <>
    <div className="toolbar"><input className="search-input" type="search" value={query} onChange={e=>setQuery(e.target.value)} placeholder={t("search")} aria-label={t("search")}/><select className="sort-select" value={sort} onChange={e=>setSort(e.target.value)} aria-label={t("sortName")}><option value="newest">{t("sortNewest")}</option><option value="price-up">{t("sortCheap")}</option><option value="price-down">{t("sortExpensive")}</option><option value="name">{t("sortName")}</option></select></div>
    <div className="chip-row" aria-label={t("category")}>{categories.map(([value,label])=><button key={value} className={`chip ${category===value?"active":""}`} onClick={()=>setCategory(value)} aria-pressed={category===value}>{label}</button>)}</div>
    <p className="muted" style={{fontSize:10,marginBottom:16}}>{results.length} {t("pieces")}</p>
    {results.length ? <div className="product-grid">{results.map(product=><ProductCard key={product.id} product={product}/>)}</div> : <div className="empty-state">{t("noResults")}</div>}
  </>;
}
