"use client";

import Link from "next/link";
import { useEffect, useMemo, useState, type FormEvent } from "react";
import type { Product } from "@/lib/types";
import { useLanguage } from "@/components/language-provider";
import { formatNumber } from "@/lib/format";

type CartLine={productId:string;quantity:number};
type Shipping={name:string;phone:string;city:string;address:string;postalCode?:string};

export function CartClient({products}:{products:Product[]}) {
  const { t } = useLanguage();
  const [cart,setCart]=useState<CartLine[]>([]);
  const [loaded,setLoaded]=useState(false);
  const [busy,setBusy]=useState(false);
  const [message,setMessage]=useState<string|null>(null);
  const [error,setError]=useState<string|null>(null);
  const [shipping,setShipping]=useState<Shipping>({name:"",phone:"",city:"Turkistan",address:"",postalCode:""});
  useEffect(()=>{try{const stored=JSON.parse(localStorage.getItem("furnicity-cart-v1")||"[]");if(Array.isArray(stored))setCart(stored.filter(x=>x&&typeof x.productId==="string"&&Number.isInteger(x.quantity)&&x.quantity>0));}catch{/* Ignore invalid local data. */}setLoaded(true);},[]);
  useEffect(()=>{if(loaded){try{localStorage.setItem("furnicity-cart-v1",JSON.stringify(cart));}catch{/* Shopping still works in this tab if browser storage is blocked. */}window.dispatchEvent(new CustomEvent("furnicity:cart-changed"));}},[cart,loaded]);
  const lines=useMemo(()=>cart.map(line=>({...line,product:products.find(p=>p.id===line.productId)})).filter(line=>line.product),[cart,products]);
  const total=lines.reduce((sum,line)=>sum+(line.product?.price??0)*line.quantity,0);
  function update(id:string,delta:number){
    const product=products.find(item=>item.id===id);
    const maxQuantity=Math.max(0,product?.stock_quantity??1000);
    setCart(items=>items.map(item=>item.productId===id?{...item,quantity:Math.max(0,Math.min(maxQuantity,item.quantity+delta))}:item).filter(item=>item.quantity>0));
    setMessage(null);
  }
  function remove(id:string){setCart(items=>items.filter(item=>item.productId!==id));setMessage(null);}
  async function checkout(e:FormEvent<HTMLFormElement>){e.preventDefault();setError(null);setMessage(null);setBusy(true);try{const payload={items:lines.map(line=>({product_id:line.productId,quantity:line.quantity})),shipping_address:{name:shipping.name,city:shipping.city,address:shipping.address,postal_code:shipping.postalCode},buyer_phone:shipping.phone,idempotency_key:crypto.randomUUID()};const response=await fetch("/api/orders",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(payload)});const result=await response.json();if(!response.ok)throw new Error(result.error||"Could not submit the order.");setCart([]);setMessage(`${t("orderSuccess")} Reference: ${(result.data??[]).map((x:{order_number:string})=>x.order_number).join(", ")}.`);}catch(err){setError(err instanceof Error?err.message:"Checkout failed.");}finally{setBusy(false);}}
  if(!loaded)return <div className="loading">{t("loading")}</div>;
  if(lines.length===0)return <div>{message&&<div className="notice" role="status">{message}</div>}<div className="empty-state">{t("cartEmpty")} <Link className="inline-link" href="/catalog">{t("browseCatalog")}</Link></div></div>;
  return <div className="route-two-col"><div className="cart-list">{lines.map(({product,quantity})=>product&&<article className="cart-row" key={product.id}><div className="cart-thumb"><span style={{fontSize:22}}>▱</span></div><div><Link href={`/catalog/${product.slug}`}><strong style={{fontSize:12}}>{product.title}</strong></Link><div className="muted" style={{fontSize:10}}>{formatNumber(product.price)} ₸ · {product.store_name}</div><div className="quantity-controls" style={{marginTop:8}}><button type="button" aria-label={t("decrease")} onClick={()=>update(product.id,-1)}>−</button><span>{quantity}</span><button type="button" aria-label={t("increase")} onClick={()=>update(product.id,1)}>+</button><button type="button" aria-label={t("remove")} onClick={()=>remove(product.id)}>×</button></div></div><strong style={{fontSize:12}}>{formatNumber(product.price*quantity)} ₸</strong></article>)}</div><aside className="info-card"><div className="eyebrow">{t("orderSummary")}</div><div className="store-meta"><span>{lines.length} {t("itemLines")}</span><strong>{formatNumber(total)} ₸</strong></div><div className="notice">{t("checkoutNote")}</div><form className="form-stack" onSubmit={checkout}><label className="field">{t("fullName")}<input value={shipping.name} onChange={e=>setShipping(s=>({...s,name:e.target.value}))} maxLength={100} required autoComplete="name"/></label><label className="field">{t("phone")}<input value={shipping.phone} onChange={e=>setShipping(s=>({...s,phone:e.target.value}))} maxLength={40} required autoComplete="tel"/></label><label className="field">{t("city")}<input value={shipping.city} onChange={e=>setShipping(s=>({...s,city:e.target.value}))} maxLength={100} required/></label><label className="field">{t("address")}<textarea value={shipping.address} onChange={e=>setShipping(s=>({...s,address:e.target.value}))} maxLength={500} required autoComplete="street-address"/></label><button className="button button-dark" type="submit" disabled={busy}>{busy?t("submitting"):t("submitOrder")}</button>{error&&<div className="notice error" role="alert">{error}</div>}{message&&<div className="notice" role="status">{message}</div>}</form></aside></div>;
}
