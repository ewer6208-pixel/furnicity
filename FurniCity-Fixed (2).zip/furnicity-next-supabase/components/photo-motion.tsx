"use client";

import { useEffect } from "react";

/** Adds a small, accessible mouse-parallax shift to photo cards site-wide. */
export function PhotoMotion() {
  useEffect(() => {
    const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)");
    const onMove = (event: PointerEvent) => {
      if (event.pointerType === "touch" || reducedMotion.matches) return;
      const origin = event.target instanceof Element ? event.target.closest<HTMLElement>("[data-photo-motion]") : null;
      if (!origin) return;
      const rect = origin.getBoundingClientRect();
      if (!rect.width || !rect.height) return;
      const x = (event.clientX - rect.left) / rect.width - 0.5;
      const y = (event.clientY - rect.top) / rect.height - 0.5;
      origin.style.setProperty("--photo-x", `${-x * 10}px`);
      origin.style.setProperty("--photo-y", `${-y * 8}px`);
    };
    const onLeave = (event: PointerEvent) => {
      if (!(event.target instanceof Element)) return;
      const origin = event.target.closest<HTMLElement>("[data-photo-motion]");
      const next = event.relatedTarget instanceof Element ? event.relatedTarget : null;
      if (!origin || (next && origin.contains(next))) return;
      origin.style.setProperty("--photo-x", "0px");
      origin.style.setProperty("--photo-y", "0px");
    };
    document.addEventListener("pointermove", onMove, { passive: true });
    document.addEventListener("pointerout", onLeave, { passive: true });
    return () => {
      document.removeEventListener("pointermove", onMove);
      document.removeEventListener("pointerout", onLeave);
    };
  }, []);
  return null;
}
