"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useState, type FormEvent } from "react";
import { useLanguage, type Language } from "@/components/language-provider";

export function SiteHeader() {
  const pathname = usePathname();
  const router = useRouter();
  const { language, setLanguage, t } = useLanguage();
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [cartCount, setCartCount] = useState(0);
  const [favoriteCount, setFavoriteCount] = useState(0);
  const links = [
    ["/", t("home")], ["/catalog", t("catalog")], ["/stores", t("stores")],
    ["/compare", t("priceAnalytics")], ["/services", t("services")], ["/news", t("journal")],
  ] as const;
  useEffect(() => {
    const syncCounts = () => {
      try {
        const cart = JSON.parse(localStorage.getItem("furnicity-cart-v1") || "[]") as Array<{ quantity?: number }>;
        const favorites = JSON.parse(localStorage.getItem("furnicity-favorites-v1") || "[]") as unknown[];
        setCartCount(Array.isArray(cart) ? cart.reduce((sum, item) => sum + Math.max(0, Number(item?.quantity) || 0), 0) : 0);
        setFavoriteCount(Array.isArray(favorites) ? favorites.length : 0);
      } catch { setCartCount(0); setFavoriteCount(0); }
    };
    syncCounts();
    window.addEventListener("storage", syncCounts);
    window.addEventListener("furnicity:cart-changed", syncCounts);
    window.addEventListener("furnicity:favorites-changed", syncCounts);
    return () => {
      window.removeEventListener("storage", syncCounts);
      window.removeEventListener("furnicity:cart-changed", syncCounts);
      window.removeEventListener("furnicity:favorites-changed", syncCounts);
    };
  }, []);
  function submitSearch(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const value = query.trim();
    router.push(value ? `/catalog?q=${encodeURIComponent(value)}` : "/catalog");
    setOpen(false);
  }
  return <header className="site-header">
    <Link className="brand" href="/" onClick={() => setOpen(false)} aria-label="FurniCity home">
      <span className="brand-mark" aria-hidden="true">⌂</span><span className="brand-text"><b>FurniCity</b><small>TURKISTAN FURNITURE HUB</small></span>
    </Link>
    <nav className={`main-nav ${open ? "is-open" : ""}`} aria-label="Main navigation">
      {links.map(([href, label]) => <Link key={href} href={href} aria-current={pathname === href ? "page" : undefined} onClick={() => setOpen(false)}>{label}</Link>)}
    </nav>
    <form className="header-search-form" role="search" onSubmit={submitSearch}>
      <span aria-hidden="true">⌕</span><input value={query} onChange={event => setQuery(event.target.value)} type="search" placeholder={t("search")} aria-label={t("search")} maxLength={120}/>
      <button type="submit" aria-label={t("search")}>↵</button>
    </form>
    <div className="header-actions">
      <label className="language-picker"><span className="sr-only">Language</span><select className="language-select" aria-label="Language" value={language} onChange={event => setLanguage(event.target.value as Language)}><option value="kk">KZ</option><option value="ru">RU</option><option value="en">EN</option></select></label>
      <Link className="header-icon-link" href="/favorites" aria-label={t("favorites")} title={t("favorites")}>♡{favoriteCount > 0 && <span className="header-count">{favoriteCount}</span>}</Link>
      <Link className="header-icon-link" href="/cart" aria-label={t("cart")} title={t("cart")}>▱{cartCount > 0 && <span className="header-count">{cartCount}</span>}</Link>
      <Link className="button button-outline desktop-only" href="/seller">{t("seller")} ↗</Link>
      <Link className="button button-dark sign-in-link" href="/auth/login">{t("signIn")} ↗</Link>
      <button className="menu-toggle" aria-expanded={open} aria-label="Toggle navigation" onClick={() => setOpen(v => !v)}>{open ? "×" : "☰"}</button>
    </div>
  </header>;
}
