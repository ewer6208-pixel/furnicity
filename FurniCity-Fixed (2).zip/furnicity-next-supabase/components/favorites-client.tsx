"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import type { Product } from "@/lib/types";
import { ProductCard } from "@/components/product-card";
import { useLanguage } from "@/components/language-provider";

export function FavoritesClient({ products }: { products: Product[] }) {
  const { t } = useLanguage();
  const [ids, setIds] = useState<string[]>([]);
  useEffect(() => {
    const sync = () => {
      try { const parsed: unknown = JSON.parse(localStorage.getItem("furnicity-favorites-v1") || "[]"); setIds(Array.isArray(parsed) ? parsed.filter((id): id is string => typeof id === "string") : []); }
      catch { setIds([]); }
    };
    sync();
    window.addEventListener("furnicity:favorites-changed", sync);
    window.addEventListener("storage", sync);
    return () => { window.removeEventListener("furnicity:favorites-changed", sync); window.removeEventListener("storage", sync); };
  }, []);
  const items = ids.map(id => products.find(product => product.id === id)).filter((product): product is Product => Boolean(product));
  if (!items.length) return <div className="empty-state">{t("emptyFavorites")}<br/><Link className="button button-dark" href="/catalog" style={{ marginTop: 15 }}>{t("browseCatalog")}</Link></div>;
  return <><div className="product-grid">{items.map(product => <ProductCard key={product.id} product={product}/>)}</div><p className="muted" style={{fontSize:10,marginTop:18}}>{items.length} {t("pieces")}</p></>;
}
