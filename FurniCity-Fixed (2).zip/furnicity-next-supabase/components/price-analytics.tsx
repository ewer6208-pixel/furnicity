"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import type { Product } from "@/lib/types";
import { useLanguage } from "@/components/language-provider";
import { formatNumber } from "@/lib/format";

const COMPARE_KEY = "furnicity-compare-v1";
function readCompare(): string[] { try { const value: unknown = JSON.parse(localStorage.getItem(COMPARE_KEY) || "[]"); return Array.isArray(value) ? value.filter((id): id is string => typeof id === "string") : []; } catch { return []; } }
function emitCompareChange() { window.dispatchEvent(new CustomEvent("furnicity:compare-changed")); }

export function PriceAnalytics({ products }: { products: Product[] }) {
  const { language, t } = useLanguage();
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("sofas");
  const [compared, setCompared] = useState<string[]>([]);
  const [message, setMessage] = useState("");
  const formatMoney = (price: number) => formatNumber(price) + " ₸";
  const categories = [ ["all", t("allCategories")], ["sofas", t("sofas")], ["beds", t("beds")], ["tables", t("tables")], ["chairs", t("chairs")], ["storage", t("storage")], ["decor", t("decor")] ] as const;
  useEffect(() => {
    const sync = () => setCompared(readCompare());
    sync(); window.addEventListener("furnicity:compare-changed", sync); window.addEventListener("storage", sync);
    return () => { window.removeEventListener("furnicity:compare-changed", sync); window.removeEventListener("storage", sync); };
  }, []);
  const offers = useMemo(() => {
    const q = query.trim().toLocaleLowerCase();
    return products.filter(product => (category === "all" || product.category_slug === category) && (!q || `${product.title} ${product.description ?? ""} ${product.store_name ?? ""} ${product.category_slug} ${t(product.category_slug)}`.toLocaleLowerCase().includes(q))).slice().sort((a,b) => a.price - b.price);
  }, [products, query, category, language, t]);
  const average = offers.length ? Math.round(offers.reduce((total, product) => total + product.price, 0) / offers.length) : 0;
  const low = offers[0]?.price ?? 0;
  const high = offers[offers.length - 1]?.price ?? 0;
  function toggleCompare(product: Product) {
    const next = [...compared];
    if (next.includes(product.id)) next.splice(next.indexOf(product.id), 1);
    else if (next.length >= 3) { setMessage(t("compareLimit")); window.setTimeout(() => setMessage(""), 2200); return; }
    else next.push(product.id);
    try { localStorage.setItem(COMPARE_KEY, JSON.stringify(next)); } catch { /* Storage may be unavailable. */ }
    setCompared(next); emitCompareChange(); setMessage("");
  }
  const selected = compared.map(id => products.find(product => product.id === id)).filter((product): product is Product => Boolean(product));
  return <>
    <div className="price-analysis-tools">
      <label><span>{t("searchProducts")}</span><input type="search" value={query} onChange={event => setQuery(event.target.value)} placeholder={t("search")} maxLength={120}/></label>
      <label><span>{t("category")}</span><select value={category} onChange={event => setCategory(event.target.value)}>{categories.map(([value,label]) => <option key={value} value={value}>{label}</option>)}</select></label>
    </div>
    {offers.length ? <>
      <div className="price-analysis-stats">
        <article><span>{t("offersCompared")}</span><strong>{offers.length}</strong></article>
        <article className="price-analysis-low"><span>{t("lowest")}</span><strong>{formatMoney(low)}</strong></article>
        <article><span>{t("average")}</span><strong>{formatMoney(average)}</strong></article>
        <article><span>{t("highest")}</span><strong>{formatMoney(high)}</strong></article>
      </div>
      <div className="price-analysis-difference"><span>{t("potentialSavings")} · {t("difference")}</span><strong>{formatMoney(Math.max(0, high-low))}</strong></div>
      <h2 className="section-subtitle-heading">{t("priceOffers")}</h2>
      <div className="price-analysis-table-wrap"><table className="price-analysis-table"><thead><tr><th>{t("product")}</th><th>{t("store")}</th><th>{t("price")}</th><th>{t("stock")}</th><th>{t("compare")}</th></tr></thead><tbody>{offers.map((product,index) => <tr key={product.id}><td><Link className="price-analysis-product" href={`/catalog/${product.slug}`}>{product.title}</Link><small>{product.category_slug}</small></td><td>{product.store_name ?? "Local store"}</td><td className="price-analysis-price">{formatMoney(product.price)}{index===0&&<span className="price-analysis-badge">{t("lowestBadge")}</span>}</td><td>{product.stock_quantity}</td><td><button className={`button ${compared.includes(product.id)?"button-dark":"button-outline"} price-analysis-compare`} type="button" onClick={() => toggleCompare(product)}>{compared.includes(product.id)?t("removeCompare"):t("addCompare")}</button></td></tr>)}</tbody></table></div>
    </> : <div className="empty-state">{t("noPriceResults")}</div>}
    {message&&<p className="notice" role="status">{message}</p>}
    <p className="notice price-analysis-note">{t("priceNote")}</p>
    <section className="selected-compare-section"><div className="section-head"><div><div className="eyebrow">FURNICITY / SIDE BY SIDE</div><h2>{t("selectedCompare")}</h2></div><div className="selected-compare-actions"><Link href="/catalog" className="button button-outline">{t("browseCatalog")}</Link>{selected.length>0&&<button className="button button-outline" type="button" onClick={() => { try { localStorage.setItem(COMPARE_KEY,"[]"); } catch { /* Storage may be unavailable. */ } setCompared([]); emitCompareChange(); }}>{t("clearCompare")}</button>}</div></div>
      {selected.length ? <div className="price-analysis-table-wrap"><table className="price-analysis-table"><thead><tr><th>{t("product")}</th>{selected.map(product=><th key={product.id}>{product.title}</th>)}</tr></thead><tbody><tr><td>{t("price")}</td>{selected.map(product=><td key={product.id} className="price-analysis-price">{formatMoney(product.price)}</td>)}</tr><tr><td>{t("category")}</td>{selected.map(product=><td key={product.id}>{t(product.category_slug as "sofas"|"beds"|"tables"|"chairs"|"storage"|"decor")}</td>)}</tr><tr><td>{t("store")}</td>{selected.map(product=><td key={product.id}>{product.store_name ?? "Local store"}</td>)}</tr><tr><td>{t("stock")}</td>{selected.map(product=><td key={product.id}>{product.stock_quantity}</td>)}</tr></tbody></table></div> : <p className="empty-state">{t("emptyCompare")}</p>}
    </section>
  </>;
}
