# Supabase-пен байланыстыру (қадамдар)

1. https://supabase.com → **New project** жасаңыз (Region: Frankfurt немесе жақын). Деректер базасының паролін сақтап қойыңыз.
2. **SQL Editor → New query** → `supabase/migrations/001_initial_schema.sql` файлының ішіндегі БАРЛЫҒЫН көшіріп қойып, **Run** басыңыз. Бұл кестелерді, қауіпсіздік ережелерін (RLS), санаттарды, 3 үлгі дүкен мен 8 үлгі тауарды жасайды. Файлды тек БІР рет іске қосыңыз.
3. **Project Settings → API**: `Project URL` және `Publishable key` (немесе `anon public`) көшіріңіз.
4. Жоба папкасында `.env.local` жасаңыз (`powershell -File scripts/setup-env.ps1`) және толтырыңыз:
   ```
   NEXT_PUBLIC_SUPABASE_URL=https://xxxx.supabase.co
   NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY=sb_publishable_...
   NEXT_PUBLIC_SITE_URL=http://localhost:3000
   ```
   `service_role` кілтін ешқашан осында жазбаңыз.
5. **Authentication → URL Configuration**: Site URL = `http://localhost:3000`; Redirect URLs тізіміне `http://localhost:3000/auth/callback` қосыңыз.
6. Тестілеу үшін: **Authentication → Sign In / Providers → Email** ішінде "Confirm email" өшіріңіз (кейін, нақты сайтта, қайта қосыңыз).
7. Тексеру: `npm run check:supabase` — үш PASS шығуы керек.
8. `npm run dev` қайта іске қосыңыз. Сайттан тіркеліңіз, содан кейін `supabase/make-admin.sql` ішіндегі SQL-ді (өз email-іңізбен) іске қосыңыз.

Google/Apple кіру үшін Authentication → Providers ішінде жеке баптау керек (міндетті емес).
