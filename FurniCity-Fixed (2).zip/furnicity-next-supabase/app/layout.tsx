import type { Metadata } from "next";
import "./globals.css";
import { SiteHeader } from "@/components/site-header";
import { SiteFooter } from "@/components/site-footer";
import { PhotoMotion } from "@/components/photo-motion";
import { LanguageProvider } from "@/components/language-provider";

export const metadata: Metadata = {
  metadataBase: new URL(process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000"),
  title: { default: "FurniCity — Turkistan Furniture Hub", template: "%s | FurniCity" },
  description: "Discover furniture. Connect with local sellers. Shop furniture in Turkistan, Kazakhstan.",
  openGraph: { title: "FurniCity — Turkistan Furniture Hub", description: "A local furniture marketplace for Turkistan.", type: "website" },
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="kk" data-scroll-behavior="smooth"><body><LanguageProvider><div className="announcement"><span className="status-dot" /><span data-i18n-key="announcement">Turkistan furniture stores — all in one place</span><a href="/stores" data-i18n-key="meetSellers">Meet local sellers ↗</a></div><SiteHeader />{children}<SiteFooter /><PhotoMotion /></LanguageProvider></body></html>;
}
