import type { Metadata } from "next";
import { FavoritesClient } from "@/components/favorites-client";
import { getProducts } from "@/lib/data";
export const metadata: Metadata = { title: "Favorites" };
export default async function FavoritesPage(){const products=await getProducts();return <main className="container page-content"><header className="page-header"><div className="eyebrow">FURNICITY / SAVED PIECES</div><h1 className="page-title" data-i18n-key="favoritesTitle">Your personal shortlist.</h1><p className="page-lead" data-i18n-key="favoritesLead">Furniture you save stays on this device and appears here.</p></header><FavoritesClient products={products}/></main>;}
