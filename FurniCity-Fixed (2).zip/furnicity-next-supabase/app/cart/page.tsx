import type { Metadata } from "next";
import { getProducts } from "@/lib/data";
import { CartClient } from "@/components/cart-client";
export const metadata: Metadata={title:"Shopping bag"};
export default async function CartPage(){const products=await getProducts();return <main className="container page-content"><header className="page-header"><div className="eyebrow">YOUR SELECTION</div><h1 className="page-title" data-i18n-key="cartTitle">Shopping bag.</h1><p className="page-lead" data-i18n-key="cartLead">Review your furniture and send a request to the relevant local stores.</p></header><CartClient products={products}/></main>;}
