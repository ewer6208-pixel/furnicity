import { NextResponse } from "next/server";
import { getProducts } from "@/lib/data";
export async function GET(){const products=await getProducts();return NextResponse.json({data:products,source:process.env.NEXT_PUBLIC_SUPABASE_URL?"supabase-or-demo-fallback":"demo"},{headers:{"Cache-Control":"public, s-maxage=30, stale-while-revalidate=120"}});}
