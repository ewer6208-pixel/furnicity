import { NextResponse } from "next/server";
import { getStores } from "@/lib/data";
export async function GET(){const stores=await getStores();return NextResponse.json({data:stores},{headers:{"Cache-Control":"public, s-maxage=30, stale-while-revalidate=120"}});}
