import { NextResponse, type NextRequest } from "next/server";
import { createClient } from "@/lib/supabase/server";

const uuidPattern=/^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
export async function POST(request:NextRequest){
  const origin=request.headers.get("origin");
  if(origin && origin!==request.nextUrl.origin)return NextResponse.json({error:"Cross-origin request blocked."},{status:403});
  const supabase=await createClient();
  if(!supabase)return NextResponse.json({error:"Supabase is not configured yet."},{status:503});
  const {data:{user}}=await supabase.auth.getUser();
  if(!user)return NextResponse.json({error:"Sign in before submitting an order."},{status:401});
  let body:unknown;try{body=await request.json();}catch{return NextResponse.json({error:"Invalid JSON."},{status:400});}
  if(!body||typeof body!=="object")return NextResponse.json({error:"Invalid request body."},{status:400});
  const value=body as Record<string,unknown>;
  if(!Array.isArray(value.items)||value.items.length<1||value.items.length>30)return NextResponse.json({error:"Choose between 1 and 30 product lines."},{status:400});
  const items=[] as Array<{product_id:string;quantity:number}>;
  for(const item of value.items){if(!item||typeof item!=="object")return NextResponse.json({error:"Invalid item."},{status:400});const row=item as Record<string,unknown>;if(typeof row.product_id!=="string"||!uuidPattern.test(row.product_id)||!Number.isInteger(row.quantity)||(row.quantity as number)<1||(row.quantity as number)>1000)return NextResponse.json({error:"Each item needs a valid product ID and quantity."},{status:400});items.push({product_id:row.product_id,quantity:row.quantity as number});}
  if(!value.shipping_address||typeof value.shipping_address!=="object"||Array.isArray(value.shipping_address))return NextResponse.json({error:"Shipping address is required."},{status:400});
  const raw=value.shipping_address as Record<string,unknown>;
  const name=typeof raw.name==="string"?raw.name.trim().slice(0,100):"";
  const city=typeof raw.city==="string"?raw.city.trim().slice(0,100):"";
  const address=typeof raw.address==="string"?raw.address.trim().slice(0,500):"";
  const phone=typeof value.buyer_phone==="string"?value.buyer_phone.trim().slice(0,40):"";
  if(name.length<2||city.length<2||address.length<4||phone.length<5)return NextResponse.json({error:"Enter your name, city, delivery address, and contact phone."},{status:400});
  const idempotency=typeof value.idempotency_key==="string"&&uuidPattern.test(value.idempotency_key)?value.idempotency_key:null;
  const {data,error}=await supabase.rpc("place_order",{p_items:items,p_shipping_address:{name,city,address,postal_code:typeof raw.postal_code==="string"?raw.postal_code.slice(0,30):""},p_buyer_phone:phone,p_idempotency_key:idempotency});
  if(error){const safeMessage=/insufficient stock|unavailable|invalid item quantity|sign in required|shipping address|order must contain/i.test(error.message)?error.message:"Order request could not be processed. Check that the Supabase migration is installed and that the items are available.";return NextResponse.json({error:safeMessage},{status:400});}
  return NextResponse.json({data,notice:"This is an order request; no payment was collected."},{status:201});
}
