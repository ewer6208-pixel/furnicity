import type { MetadataRoute } from "next";
export default function robots(): MetadataRoute.Robots {
  const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000";
  return { rules: { userAgent: "*", allow: ["/", "/catalog", "/stores", "/services", "/about", "/news"], disallow: ["/account", "/admin", "/orders", "/api/"] }, sitemap: `${siteUrl}/sitemap.xml` };
}
