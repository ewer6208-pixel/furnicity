import type { Metadata } from "next";
import { Suspense } from "react";
import Link from "next/link";
import { OAuthButtons } from "@/components/oauth-buttons";
import { EmailAuthForm } from "@/components/email-auth-form";
export const metadata: Metadata = { title: "Sign in" };
export default function LoginPage(){return <main className="container page-content"><div className="auth-card"><div className="eyebrow">FURNICITY / MEMBER ACCESS</div><h1>Welcome back.</h1><p className="lead">Sign in to save furniture, manage your store, and track inquiries.</p><Suspense fallback={<div className="loading">Loading sign-in options…</div>}><OAuthButtons/></Suspense><EmailAuthForm/><div className="notice">Google and Apple sign-in require provider setup in your own Supabase project. See the README. This app never asks for an Apple ID password directly.</div><p className="muted" style={{fontSize:10,marginTop:16}}>By continuing, you agree to our <Link className="inline-link" href="/terms">Terms</Link> and <Link className="inline-link" href="/privacy">Privacy Policy</Link>.</p></div></main>;}
