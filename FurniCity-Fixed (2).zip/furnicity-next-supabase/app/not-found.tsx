import Link from "next/link";
export default function NotFound(){return <main className="container page-content"><div className="auth-card"><div className="eyebrow">404 / NOT FOUND</div><h1>That page is not here.</h1><p className="lead">The page may have moved or the link may be incorrect.</p><Link className="button button-dark" href="/">Return home ↗</Link></div></main>;}
