import type { MetadataRoute } from "next";
import { getProducts, getStores } from "@/lib/data";
export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000";
  const paths = ["", "/catalog", "/categories", "/stores", "/services", "/about", "/news", "/seller", "/support", "/privacy", "/terms"];
  const [products, stores] = await Promise.all([getProducts(), getStores()]);
  const staticEntries = paths.map(path => ({ url: `${siteUrl}${path}`, changeFrequency: path === "" ? "daily" as const : "weekly" as const, priority: path === "" ? 1 : 0.6 }));
  const productEntries = products.map(p => ({ url: `${siteUrl}/catalog/${p.slug}`, changeFrequency: "weekly" as const, priority: 0.5 }));
  const storeEntries = stores.map(s => ({ url: `${siteUrl}/stores/${s.slug}`, changeFrequency: "weekly" as const, priority: 0.5 }));
  return [...staticEntries, ...productEntries, ...storeEntries];
}
