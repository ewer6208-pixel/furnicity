import type { Metadata } from "next";
import { PriceAnalytics } from "@/components/price-analytics";
import { getProducts } from "@/lib/data";
export const metadata: Metadata = { title: "Price analytics", description: "Automatically compare furniture prices from available FurniCity offers." };
export default async function ComparePage(){const products=await getProducts();return <main className="container page-content"><header className="page-header"><div className="eyebrow">FURNICITY / PRICE INSIGHTS</div><h1 className="page-title" data-i18n-key="priceTitle">Choose with confidence.</h1><p className="page-lead" data-i18n-key="priceLead">Compare offers by furniture type and see the lowest, average, and highest price in one place.</p></header><PriceAnalytics products={products}/></main>;}
