import type { Metadata } from "next";
import { CatalogExplorer } from "@/components/catalog-explorer";
import { getProducts } from "@/lib/data";
export const metadata: Metadata = { title: "Furniture catalog", description: "Browse and compare furniture from local Turkistan stores." };
export default async function CatalogPage({searchParams}:{searchParams:Promise<{category?:string;q?:string}>}){
  const [products,params]=await Promise.all([getProducts(),searchParams]);
  const allowed=["sofas","beds","tables","chairs","storage","decor"];
  const initialCategory=params.category&&allowed.includes(params.category)?params.category:"all";
  const initialQuery=typeof params.q==="string"?params.q.slice(0,120):"";
  return <main className="container page-content"><header className="page-header"><div className="eyebrow" data-i18n-key="collection">FURNICITY / THE COLLECTION</div><h1 className="page-title" data-i18n-key="findPiece">Find the piece <em>that fits.</em></h1><p className="page-lead" data-i18n-key="collectionLead">Thoughtfully selected furniture from Turkistan stores.</p></header><CatalogExplorer products={products} initialCategory={initialCategory} initialQuery={initialQuery}/></main>;
}
