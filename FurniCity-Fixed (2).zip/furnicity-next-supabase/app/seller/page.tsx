import type { Metadata } from "next";
import { SellerDashboard } from "@/components/seller-dashboard";
export const metadata: Metadata = { title: "Seller studio" };
export default function SellerPage(){return <main className="container page-content"><header className="page-header"><div className="eyebrow">LOCAL BUSINESS / SELLER STUDIO</div><h1 className="page-title" data-i18n-key="sellerPageTitle">Your store, <em>your digital space.</em></h1><p className="page-lead" data-i18n-key="sellerPageLead">Create a store profile, manage furniture listings, and reach customers across Turkistan.</p></header><SellerDashboard/></main>;}
