import type { Metadata } from "next";
import Link from "next/link";
import { SellerProductForm } from "@/components/seller-product-form";
export const metadata: Metadata = { title: "Add furniture" };
export default function NewProductPage(){return <main className="container page-content"><header className="page-header"><div className="eyebrow">SELLER STUDIO / CATALOG</div><h1 className="page-title">List a new <em>piece.</em></h1><p className="page-lead">New products are saved as drafts and should be approved before public publication.</p></header><div className="auth-card" style={{margin:"0",maxWidth:680}}><SellerProductForm/><p className="muted" style={{fontSize:10,marginTop:18}}><Link href="/seller" className="inline-link">← Back to seller studio</Link></p></div></main>;}
