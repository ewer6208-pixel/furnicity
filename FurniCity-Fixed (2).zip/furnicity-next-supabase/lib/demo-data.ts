import type { Product, Store } from "@/lib/types";

export const demoStores: Store[] = [
  { id: "demo-store-1", name: "Qara Wood Studio", slug: "qara-wood-studio", description: "Solid wood, quiet shapes, made for everyday living.", city: "Turkistan", phone: null, logo_url: null },
  { id: "demo-store-2", name: "Nomad Home", slug: "nomad-home", description: "Warm materials and thoughtful furniture for modern homes.", city: "Turkistan", phone: null, logo_url: null },
  { id: "demo-store-3", name: "Forma Living", slug: "forma-living", description: "Contemporary furniture for compact, considered spaces.", city: "Turkistan", phone: null, logo_url: null },
];

export const demoProducts: Product[] = [
  { id: "demo-1", slug: "luma-modular-sofa", title: "Luma Modular Sofa", description: "Soft modular sofa with textured upholstery and deep seats.", category_slug: "sofas", price: 389000, currency: "KZT", stock_quantity: 4, image_url: null, store_id: "demo-store-1", store_name: "Qara Wood Studio", store_slug: "qara-wood-studio", city: "Turkistan" },
  { id: "demo-2", slug: "forma-lounge-chair", title: "Forma Lounge Chair", description: "Sculptural accent chair with a curved back and oak legs.", category_slug: "chairs", price: 128000, currency: "KZT", stock_quantity: 7, image_url: null, store_id: "demo-store-3", store_name: "Forma Living", store_slug: "forma-living", city: "Turkistan" },
  { id: "demo-3", slug: "noma-oak-table", title: "Noma Oak Dining Table", description: "A solid oak dining table for slow mornings and long dinners.", category_slug: "tables", price: 245000, currency: "KZT", stock_quantity: 3, image_url: null, store_id: "demo-store-1", store_name: "Qara Wood Studio", store_slug: "qara-wood-studio", city: "Turkistan" },
  { id: "demo-4", slug: "sora-platform-bed", title: "Sora Platform Bed", description: "Low-profile bed frame with an architectural silhouette.", category_slug: "beds", price: 315000, currency: "KZT", stock_quantity: 5, image_url: null, store_id: "demo-store-2", store_name: "Nomad Home", store_slug: "nomad-home", city: "Turkistan" },
  { id: "demo-5", slug: "aru-sideboard", title: "Aru Sideboard", description: "Clean-lined storage with generous hidden space.", category_slug: "storage", price: 198000, currency: "KZT", stock_quantity: 6, image_url: null, store_id: "demo-store-2", store_name: "Nomad Home", store_slug: "nomad-home", city: "Turkistan" },
  { id: "demo-6", slug: "tumar-ceramic-lamp", title: "Tumar Ceramic Lamp", description: "A sculptural lamp with a quiet, warm presence.", category_slug: "decor", price: 42000, currency: "KZT", stock_quantity: 12, image_url: null, store_id: "demo-store-3", store_name: "Forma Living", store_slug: "forma-living", city: "Turkistan" },
  { id: "demo-7", slug: "kieli-two-seater", title: "Kieli Two-Seater", description: "A compact two-seater designed for apartment living.", category_slug: "sofas", price: 279000, currency: "KZT", stock_quantity: 3, image_url: null, store_id: "demo-store-3", store_name: "Forma Living", store_slug: "forma-living", city: "Turkistan" },
  { id: "demo-8", slug: "aspan-coffee-table", title: "Aspan Coffee Table", description: "Rounded coffee table with a matte mineral finish.", category_slug: "tables", price: 89000, currency: "KZT", stock_quantity: 8, image_url: null, store_id: "demo-store-2", store_name: "Nomad Home", store_slug: "nomad-home", city: "Turkistan" }
];
