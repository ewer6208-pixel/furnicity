import { createClient } from "@/lib/supabase/server";
import { demoProducts, demoStores } from "@/lib/demo-data";
import type { Product, Store } from "@/lib/types";

type StoreRef = { name: string; slug: string; city: string };
type ProductRow = Omit<Product, "store_name" | "store_slug" | "city" | "price"> & {
  price: number | string;
  stores: StoreRef | StoreRef[] | null;
};

// Supabase not configured (no .env.local) -> demo data.
// Supabase configured but a query fails (e.g. migration not run) -> demo data + clear message in the server terminal.
// Supabase configured and the table is simply empty -> empty list (demo IDs are not UUIDs and would break checkout).
export async function getProducts(): Promise<Product[]> {
  const supabase = await createClient();
  if (!supabase) return demoProducts;
  const { data, error } = await supabase
    .from("products")
    .select("id,slug,title,description,category_slug,price,currency,stock_quantity,image_url,store_id,stores(name,slug,city)")
    .eq("status", "published")
    .order("created_at", { ascending: false })
    .limit(100);
  if (error) {
    console.error("[FurniCity] Could not load products from Supabase:", error.message, "- run supabase/migrations/001_initial_schema.sql in the SQL Editor.");
    return demoProducts;
  }
  return (data as unknown as ProductRow[]).map((row) => {
    const store = Array.isArray(row.stores) ? row.stores[0] : row.stores;
    const { stores: _stores, ...rest } = row;
    void _stores;
    return { ...rest, price: Number(row.price), store_name: store?.name ?? "Local seller", store_slug: store?.slug, city: store?.city } as Product;
  });
}

export async function getStores(): Promise<Store[]> {
  const supabase = await createClient();
  if (!supabase) return demoStores;
  const { data, error } = await supabase.from("stores").select("id,name,slug,description,city,phone,logo_url").eq("status", "active").order("created_at", { ascending: false }).limit(100);
  if (error) {
    console.error("[FurniCity] Could not load stores from Supabase:", error.message);
    return demoStores;
  }
  return data as Store[];
}

export async function getProductBySlug(slug: string): Promise<Product | null> {
  const products = await getProducts();
  return products.find((product) => product.slug === slug) ?? null;
}

export async function getStoreBySlug(slug: string): Promise<Store | null> {
  const stores = await getStores();
  return stores.find((store) => store.slug === slug) ?? null;
}
