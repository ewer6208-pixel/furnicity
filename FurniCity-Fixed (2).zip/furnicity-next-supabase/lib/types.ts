export type Category = "sofas" | "beds" | "tables" | "chairs" | "storage" | "decor";

export type Product = {
  id: string;
  slug: string;
  title: string;
  description: string | null;
  category_slug: Category;
  price: number;
  currency: string;
  stock_quantity: number;
  image_url: string | null;
  store_id: string;
  store_name?: string;
  store_slug?: string;
  city?: string;
};

export type Store = {
  id: string;
  name: string;
  slug: string;
  description: string | null;
  city: string;
  phone: string | null;
  logo_url: string | null;
  status?: string;
};
