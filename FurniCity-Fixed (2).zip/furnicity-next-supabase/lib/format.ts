/** Deterministic number formatting: identical on server and browser (no Intl/ICU differences, no hydration mismatch). */
export function formatNumber(value: number): string {
  const rounded = Math.round(Number.isFinite(value) ? value : 0);
  const sign = rounded < 0 ? "-" : "";
  return sign + String(Math.abs(rounded)).replace(/\B(?=(\d{3})+(?!\d))/g, "\u00A0");
}
