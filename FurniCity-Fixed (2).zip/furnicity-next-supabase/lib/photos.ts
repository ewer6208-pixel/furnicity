import type { Category } from "@/lib/types";

const photos: Record<Category, string> = {
  sofas: "https://images.unsplash.com/photo-1555041469-a586c61ea9bc?auto=format&fit=crop&w=1000&q=85",
  beds: "https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?auto=format&fit=crop&w=1000&q=85",
  tables: "https://images.unsplash.com/photo-1616486338812-3dadae4b4ace?auto=format&fit=crop&w=1000&q=85",
  chairs: "https://images.unsplash.com/photo-1617806118233-18e1de247200?auto=format&fit=crop&w=1000&q=85",
  storage: "https://images.unsplash.com/photo-1595428774223-ef52624120d2?auto=format&fit=crop&w=1000&q=85",
  decor: "https://images.unsplash.com/photo-1583847268964-b28dc8f51f92?auto=format&fit=crop&w=1000&q=85",
};

export const heroPhoto = "https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?auto=format&fit=crop&w=2200&q=88";
export const showroomPhoto = "https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&w=1600&q=85";
export const kitchenPhoto = "https://images.unsplash.com/photo-1600585154340-be6161a56c0a?auto=format&fit=crop&w=1000&q=85";
export const officePhoto = "https://images.unsplash.com/photo-1497366754035-f200968a6e72?auto=format&fit=crop&w=1000&q=85";

export function furniturePhoto(category: string, imageUrl?: string | null): string {
  if (imageUrl && /^https:\/\//i.test(imageUrl)) return imageUrl;
  return photos[category as Category] ?? photos.sofas;
}

export function storePhoto(slug: string, index = 0): string {
  const bySlug: Record<string, string> = {
    "qara-wood-studio": photos.tables,
    "nomad-home": heroPhoto,
    "forma-living": showroomPhoto,
  };
  return bySlug[slug] ?? [photos.tables, heroPhoto, showroomPhoto][index % 3];
}
