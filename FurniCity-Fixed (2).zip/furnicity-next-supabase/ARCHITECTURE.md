# FurniCity architecture and implementation plan

## 1. Stack

- Next.js App Router + TypeScript for distinct, indexable pages and server rendering.
- Supabase Auth and `@supabase/ssr` for cookie-based sessions across browser, Server Components, Route Handlers, and the Next.js 16 `proxy.ts` layer.
- Supabase PostgreSQL for marketplace records and Row Level Security. Public listing reads are limited to active stores and published products. Seller write access is checked against store ownership; moderation status changes are protected by a database trigger.
- Server Route Handler + transactional Postgres RPC for orders. Prices and stock are read on the server/database side instead of trusting values sent by the browser.
- Client state only for transient interactions (slider, product filters, demo favourites and local basket). User roles and private data must never be trusted from `localStorage`.

## 2. Route map

| Path | Purpose | Access |
|---|---|---|
| `/` | Landing page, hero, collection slider | Public |
| `/catalog` | Search, category filter, sorting | Public |
| `/catalog/[slug]` | Product detail and seller link | Public for published items |
| `/categories` | Furniture categories | Public |
| `/stores` | Active local store directory | Public |
| `/stores/[slug]` | Storefront and its published items | Public for active stores |
| `/services`, `/about`, `/news` | Editorial, mission, platform services | Public |
| `/auth/login` | Email/password and Google/Apple OAuth | Public |
| `/auth/callback` | Exchange OAuth code for cookie session | Auth callback |
| `/account`, `/orders` | Account and order history | Authenticated; RLS filters rows |
| `/cart` | Local basket + submit order request | Authenticated to submit |
| `/favorites`, `/compare` | Saved-item and compare routes | UI starter; cloud sync phase pending |
| `/seller` | Seller store onboarding | Authenticated; owner RLS |
| `/seller/products/new` | Create a product draft | Authenticated; own store only |
| `/admin` | Admin overview | `admin` or `super_admin` |
| `/support`, `/privacy`, `/terms` | Help and legal pages | Public |
| `/api/products`, `/api/stores` | Public catalogue endpoints | Public, cache headers |
| `/api/orders` | Validated order request endpoint | Authenticated, same-origin check + RLS/RPC |

## 3. Data model

- `profiles`: auth user id, display name, avatar, locale, role. A database trigger creates a `buyer` row and ignores any user-supplied role.
- `stores`: owner, name/slug, description, city, contact phone, status (`pending`, `active`, `suspended`).
- `categories`: stable slugs plus Kazakh/Russian/English labels.
- `products`: store, category, slug, name, description, numeric price/currency, stock, image URL, moderated status (`draft`, `pending`, `published`, `archived`, `rejected`).
- `favorites`: composite primary key `(user_id, product_id)`.
- `reviews`: one review per user/product; rating constrained to 1–5; moderation status.
- `orders`: one order per seller storefront, buyer, immutable total/currency, delivery address, phone, status, idempotency key.
- `order_items`: product and title/price snapshots at checkout; stored quantity and generated line total.
- `support_tickets`, `ad_campaigns`, `audit_events`: support, future sponsored placements, and administrator audit trail.

`place_order()` is a database transaction: it checks authentication and input shape, locks products, verifies published availability and stock, computes current database prices, splits multi-seller baskets, decrements stock, and writes orders plus item snapshots. The app only creates order requests; actual payment processing and verified provider webhooks are not implemented.

## 4. RLS and identity boundaries

- Public catalog readers see only published products and active stores.
- Users can read their profile and update only non-privileged fields; browser grants do not include updates to `profiles.role`.
- Store creation is owner-bound and initially pending. A seller can create product drafts only under an owned store.
- A database trigger blocks authenticated non-admins from changing a store/product moderation status.
- Buyers and store owners can read only orders for which they are a party; order writes happen through the security-definer RPC only.
- Admin checks use `public.is_admin()` with a fixed search path. Service-role keys are not placed in the client environment.

## 5. OAuth setup notes

- The app's callback is `/auth/callback`. Supabase's provider callback URL is usually `https://<project-ref>.supabase.co/auth/v1/callback`; this URL must be registered in Google/Apple's provider console. Separately, Supabase's allowed redirect URLs must include `http://localhost:3000/auth/callback` and the eventual production URL.
- Apple uses Sign in with Apple through the `apple` Supabase provider. It requires appropriate Apple Developer configuration and key material. An Apple web client secret expires and must be rotated as required by Apple's current policy.
- Callback `next` values are restricted to local absolute paths beginning with `/` and not `//` to avoid open redirects.

## 6. Development phases

1. **Foundation (included):** pages, routes, responsive editorial visual system, sample data, catalog filtering, slider, Supabase SSR clients, email/OAuth entry points, schema/RLS, seller profile/product draft writes, account/order reads, atomic request-order RPC.
2. **Seller operations:** image uploads and moderation queue, editable listings, stock adjustment history, seller inquiries, order status transitions, messages/notifications.
3. **Buyer conversion:** persistent cloud cart/favourites, saved addresses, order cancellation/return workflow, multilingual SEO and route dictionaries.
4. **External services:** transactional email, SMS, maps/delivery provider, Google Analytics, AI discovery, support ticket integrations.
5. **Commercial release:** payment provider/webhooks, commission calculation, advertising campaign billing, audit UI, rate limiting, load tests, monitoring, backups, restore drills, accessibility and security review.
6. **Scale:** caching, queue/worker, CDN media delivery, read replicas/partitioning after real load measurements justify them. Start as a modular monolith; do not adopt microservices prematurely.

## 7. Known limitations

- The project is a starter, not a deployed production website.
- Full Kazakh/Russian/English content dictionaries are not yet wired into Next.js routes; the separate single-file design preview has KZ/RU/EN UI switching.
- No OAuth credentials are included. Google/Apple sign-in works only after the owner configures provider settings.
- No payment, SMS, transactional email, maps, AI API, or image upload bucket is connected.
- Monitoring, production rate limiting, automated backups, moderation admin UI, and full browser/accessibility test suites remain future work.
