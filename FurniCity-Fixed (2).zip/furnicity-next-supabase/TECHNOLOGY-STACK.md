# FurniCity technology stack — beginner guide

## Which language does what?

| Technology | In this project? | Purpose |
|---|---|---|
| HTML | Yes, through React/Next.js components | Page structure and accessible content |
| JavaScript | Yes | Browser interactions, navigation, forms and UI behaviour |
| TypeScript / TSX | Yes | JavaScript with type checking for safer development; this is the main app source format |
| CSS | Yes, in `app/globals.css` | Layout, responsive design, animation, typography and colours |
| Next.js | Yes | React framework for page routes, server rendering and API endpoints |
| Supabase / PostgreSQL | Supported; requires your own project credentials | Real database, authentication, Row Level Security and saved marketplace data |
| SQL | Yes, in `supabase/migrations/001_initial_schema.sql` | Creates tables, indexes, security policies, order function and sample data |
| `.env.local` | Created on your computer from `.env.example` | Local configuration such as the Supabase project URL and public client key |
| Git | Supported via `.gitignore`; initialize Git using the commands below | Tracks changes and lets you return to earlier versions |
| Java | Not included | A different programming language/backend; it would duplicate work here unless there is a separate Java service requirement |
| PHP | Not included | Another backend option; not needed when Next.js server routes are used |

## Important distinction

Java and JavaScript are different languages. You do not need to put HTML, Java, PHP, and Next.js into every page. A maintainable version of FurniCity uses one web stack: Next.js + TypeScript/JavaScript + CSS, and Supabase for managed authentication and PostgreSQL. Add a Java or PHP service only if a real integration requirement justifies operating a second backend.

## Create `.env.local` on Windows

Open PowerShell in the `furnicity-next-supabase` folder:

```powershell
Copy-Item .env.example .env.local
```

Edit `.env.local` and fill in values from your own Supabase project. The example contains placeholders, not working credentials. Never share `.env.local`, and never put a Supabase service-role/secret key in a `NEXT_PUBLIC_*` variable. `.gitignore` already excludes `.env.local` from Git.

## Start the app

Use Node.js 20.9+ (Node 22 LTS is recommended):

```powershell
npm install
npm run dev
```

Open `http://localhost:3000`.

Without Supabase settings, the sample catalogue can run in demo mode; live accounts, store/product writes and orders need your configured Supabase project and the SQL migration applied in the Supabase SQL Editor.

## Enable Git version control

Run once in the project folder:

```powershell
git init
git add .
git status
git commit -m "Initial FurniCity project"
```

Check `git status` before committing. `.env.local` must not appear in the staged files. If Git asks for identity, configure your own name/email using `git config --global user.name "Your Name"` and `git config --global user.email "you@example.com"`.

## Live service status

- Google and Apple OAuth code is included but requires enabling each provider and setting redirect URLs in your own Supabase project.
- Online card payments, transactional email/SMS, live analytics, production monitoring, and production deployment are not configured by this starter.
- This archive includes the project source and migration. It does not include the user's private Supabase credentials or a `.git` repository.
